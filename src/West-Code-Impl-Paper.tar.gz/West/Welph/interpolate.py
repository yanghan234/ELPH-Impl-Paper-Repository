#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from sklearn.pipeline import Pipeline
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import PolynomialFeatures
from sklearn.model_selection import train_test_split
from sklearn.linear_model import Ridge,Lasso,LinearRegression

class Chi0File:
    def __init__(this,fname,npdep):
        this.fname = fname
        this.npdep = npdep

    @property
    def chi0(this):
        tmp = []
        with open(this.fname,"r") as f:
            line = f.readline()
            while line != "":
                tmp.append(this.string2complex(line))
                line = f.readline()
        assert len(tmp) == this.npdep**2
        return np.array(tmp).reshape([this.npdep,this.npdep])

    def string2complex(this,s):
        re = float(s.split()[0])
        im = float(s.split()[1])
        return np.complex(re,im)

def xq_init(nk1f,nk2f,nk3f):
    xq3d = np.zeros([nk1f*nk2f*nk3f,3])
    for i in range(nk1f):
        for j in range(nk2f):
            for k in range(nk3f):
                xq3d[i*nk2f*nk3f+j*nk3f+k] = [i/nk1f,j/nk2f,k/nk3f]
    return xq3d

if __name__ == "__main__":
    print("Dimension of coarse grid?")
    nk1 = int(input("nk1 = "))
    nk2 = int(input("nk2 = "))
    nk3 = int(input("nk3 = "))
    print("Got it! The coarse grid is (%2d,%2d,%2d)."%(nk1,nk2,nk3))

    print("Now, the dimension of fine grid?")
    nk1f = int(input("nk1f = "))
    nk2f = int(input("nk2f = "))
    nk3f = int(input("nk3f = "))
    print("Got it! The fine grid is (%2d,%2d,%2d)."%(nk1f,nk2f,nk3f))

    xq_interp = xq_init(nk1f,nk2f,nk3f) # the fine grid on which chi0 to be interpolated

    print("Do you want see the coordinate of q-point list?")
    flag = int(input("0 for yes, 1 for no : "))
    if ( flag == 0 ):
        print(xq_interp)
    else:
        pass

