.. _tutorial:

Tutorials
=========

These tutorials demonstrate how to utilize core features of **WEST**. 

Contents:

.. toctree::
   :maxdepth: 1

   tutorials/west_100.ipynb
